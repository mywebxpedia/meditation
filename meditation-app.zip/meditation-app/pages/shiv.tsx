import DeityPage from '../shared/DeityPage'

export default function Shiv() {
  return <DeityPage name='Shiv' color='bg-indigo-700' accent='text-indigo-300' />
}
