import DeityPage from '../shared/DeityPage'

export default function Waheguru() {
  return <DeityPage name='Waheguru' color='bg-yellow-500' accent='text-yellow-800' />
}
