import DeityPage from '../shared/DeityPage'

export default function Krishna() {
  return <DeityPage name='Krishna' color='bg-blue-700' accent='text-blue-200' />
}
