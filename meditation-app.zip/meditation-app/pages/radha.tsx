import DeityPage from '../shared/DeityPage'

export default function Radha() {
  return <DeityPage name='Radha' color='bg-pink-600' accent='text-pink-200' />
}
